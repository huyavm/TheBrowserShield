# BrowserShield Portable Launcher
$Host.UI.RawUI.WindowTitle = "BrowserShield - Anti-Detect Browser Manager"

Write-Host ""
Write-Host "  ========================================" -ForegroundColor Cyan
Write-Host "   BrowserShield - Portable Edition" -ForegroundColor Cyan
Write-Host "  ========================================" -ForegroundColor Cyan
Write-Host ""

Set-Location $PSScriptRoot

# Check Node.js
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Host "[ERROR] Node.js not found!" -ForegroundColor Red
    Write-Host "Please install Node.js from https://nodejs.org"
    Read-Host "Press Enter to exit"
    exit 1
}

# Install dependencies if needed
if (-not (Test-Path "node_modules")) {
    Write-Host "[INFO] Installing dependencies..." -ForegroundColor Yellow
    npm install --production
    Write-Host ""
}

Write-Host "[INFO] Starting BrowserShield server..." -ForegroundColor Green
Write-Host "[INFO] Open http://localhost:5000 in your browser" -ForegroundColor Green
Write-Host "[INFO] Press Ctrl+C to stop the server" -ForegroundColor Yellow
Write-Host ""

node server.js
