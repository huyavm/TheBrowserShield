# BrowserShield Portable Edition

## Quick Start

1. **First Time Setup:**
   - Run `Download-Browsers.bat` to setup browsers
   - Or ensure Chrome/Firefox is installed on your system

2. **Start the Application:**
   - Double-click `Start-BrowserShield.bat`
   - Open http://localhost:5000 in your browser

3. **Requirements:**
   - Node.js 18+ (https://nodejs.org)
   - Windows 10/11

## Folder Structure

```
BrowserShield-Portable/
├── Start-BrowserShield.bat    # Main launcher
├── Download-Browsers.bat      # Browser setup
├── browsers/                  # Browser binaries
│   ├── chrome/
│   └── firefox/
├── data/                      # User data (profiles, logs)
│   ├── browser-profiles/
│   └── logs/
├── public/                    # Web interface
├── config/                    # Configuration files
└── ...
```

## Features

- 🎭 Anti-detect browser profiles
- 🌐 Chrome & Firefox support
- 🔒 Fingerprint spoofing
- 🌍 Proxy support
- 📊 Session management
- 🖥️ Visible & Headless modes

## Troubleshooting

**"Node.js not found"**
- Install Node.js from https://nodejs.org

**"Browser not found"**
- Run Download-Browsers.bat
- Or install Chrome/Firefox manually

**Port 5000 in use**
- Set PORT environment variable: `set PORT=3000`

## Support

For issues and updates, visit the project repository.
